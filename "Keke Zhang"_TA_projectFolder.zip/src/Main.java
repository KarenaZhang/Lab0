/*******
 Name: Keke Zhang
 Assignment: Lab 0
 Date: 14/Jan/2023
 Notes:HelloWorld
 *******/

/**
 * create a new class
 */
public class Main {
    /**
     * default constructor
     */
    public Main(){

    }
    /**
     * print the string of Hello world!
     * @param args entrance of class
     */
    public static void main(String[] args) {

        System.out.println("Hello world!");
    }
}